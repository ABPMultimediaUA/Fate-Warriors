#include "Interactuable.h"

Interactuable::Interactuable(short _id, float _i_x, float _i_y,float _i_z) : Objeto(_id, _i_x, _i_y,  _i_z) {

}

Interactuable::~Interactuable() {
}

