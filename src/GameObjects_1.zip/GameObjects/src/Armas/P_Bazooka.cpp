#include "P_Bazooka.h"
#include <iostream>

P_Bazooka::P_Bazooka(short _id, float _i_x, float _i_y, float _i_z, short _i_danyo, short _i_id_shooter) 
: Proyectil(_id, _i_x, _i_y, _i_z, _i_danyo, _id_shooter){}

P_Bazooka::~P_Bazooka(){}


void P_Bazooka::Update(){

}

void P_Bazooka::Render(){

}