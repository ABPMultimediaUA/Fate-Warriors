#include "P_Arco.h"
#include <iostream>

P_Arco::P_Arco(short _id, float _i_x, float _i_y, float _i_z, short _i_danyo, short _i_id_shooter) 
: Proyectil(_id, _i_x, _i_y, _i_z, _i_danyo, _id_shooter){}

P_Arco::~P_Arco(){}


void P_Arco::Update(){

}

void P_Arco::Render(){

}